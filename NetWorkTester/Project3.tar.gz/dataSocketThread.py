import string
import threading
import sys
import socket
import struct
import time

class DataSocketThread(threading.Thread):
    def __init__(self,threadname, test, time, target, mode):
        threading.Thread.__init__(self,name=threadname)
        self.Test = test
        self.Time = time
        self.Target = target
        self.Mode = mode
        self.accept = False
        self.msg = ""
        #self.RRMode = self.Test.split('_')[1] == 'RR'
        #self.TCPMode = self.Test.split('_')[0] == 'TCP'
    def run():
        print("Data")