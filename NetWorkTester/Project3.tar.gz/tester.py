#!/usr/bin/env python3

import argparse
import sys
import string
from controlSocketThread import ControlSocket
import time
from dataSocketThread import DataSocketThread

if not sys.version_info[:2] == (3,4):
    print("Error: need Python 3.4 to run program")
    sys.exit(1)
else:
    print("Using Python 3.4 to run program")


def main():
    parser = argparse.ArgumentParser(description='Network tester for ECPE 177')
    parser.add_argument('--version', action='version', version='1.0',
                        help="show program version number and quit")
    parser.add_argument('--test', metavar = 'TEST', choices=['TCP_STREAM', 'TCP_RR', 'UDP_STREAM', 'UDP_RR'],
                        help = 'Set mode: TCP_STREAM, TCP_RR, UDP_STREAM, UDP_RR',default='None')
    parser.add_argument('--target', metavar='TARGET', default="None",
                        help='Target IP of client')
    parser.add_argument('--time', metavar='TIME', type=int, default=45,
                        help='enable verbose mood, default 45 second')
    parser.add_argument('--client', action='store_true',help = 'Client Mode, Need Test and Target args')
    parser.add_argument('--server', action='store_true', help = 'Server Mode')

    clientMode = False
    args = parser.parse_args()

    if args.client & args.server:
        print(parser.print_help())
    else:
        if args.client:
            if args.target == 'None' or args.test == 'None':
                print(parser.print_help())
            else:
                clientMode = True

    thread = []
    controlThread = ControlSocket('ControlThread',args.test,args.time,args.target,clientMode)
    controlThread.start()
    while not controlThread.accept:
        time.sleep(1)

    commThread = DataSocketThread('commThread', controlThread.Test, controlThread.Time, controlThread.Target, clientMode)
    controlThread.replay = True
    while not controlThread.finished:
        time.sleep(1)
    commThread.closeSocket()
    if clientMode:
        print("Finished!")
        #TODO: unpack result

    
    

if __name__ == "__main__":
    sys.exit(main())