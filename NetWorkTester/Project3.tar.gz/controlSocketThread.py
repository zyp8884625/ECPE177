import string
import threading
import sys
import socket
import struct
import time

class ControlSocket(threading.Thread):
    def __init__(self,threadname, test, time, target, mode):
        threading.Thread.__init__(self,name=threadname)
        self.Test = test
        self.Time = time
        self.Target = target
        self.Mode = mode
        self.closedDataSocket = False
        self.replay = False
        self.accept = False
        self.finished = False;
        self.msg = ""
        if mode:
            if self.Test == 'TCP_STREAM':
                self.controlData = struct.pack('!3b',1,1,1)  #Request data pack
            else:
                if self.Test == 'TCP_RR':
                    self.controlData = struct.pack('!3b',1,1,2)  #Request data pack
                else:
                     if self.Test == 'UDP_STREAM':
                        self.controlData = struct.pack('!3b',1,1,3)  #Request data pack
                     else:
                          if self.Test == 'UDP_RR':
                            self.controlData = struct.pack('!3b',1,1,4)  #Request data pack
                          else:
                            self.controlData = struct.pack('!3b',1,1,1)  #Request data pack
    def generateResult(self):
        #TODO: GenerateResult
        return pack
    def run(self):
        try:
            self.controlSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        except socket.error as msg:
            print("Error: could not create control socket")
            print("Description:" + str(msg))
            sys.exit()
        if self.Mode:
            try:
                self.controlSocket.connect((self.Target, 4567))
            except socket.error as msg:
                print("Error: could not open connecting")
                print("Description:" + str(msg))
                sys.exit()
            try:
                self.controlSocket.sendall(self.controlData)
            except socket.error as msg:
                print("Error: could not send control data")
                print("Description:" + str(msg))
                sys.exit()
            try:
                self.datapack = struct.unpack('!3b',self.controlSocket.recv(struct.calcsize('!3b')))
            except socket.error as msg:
                print("Error: Could not reveice reply message!")
                print("Description:" + str(msg))
                sys.exit(0)
            print(self.datapack)
            if self.datapack == b'Accpet':
                self.accept = True
                time.sleep(time)
            #TODO: Send Finished msg and get result
                self.controlData = struct.pack('!2b',1,3)
                try:
                    self.controlSocket.sendall(self.controlData)
                    self.finished = True
                except socket.error as msg:
                    print("Error: could not send control data")
                    print("Description:" + str(msg))
                    sys.exit()
                try:
                    self.controlSocket.recv(20)
                except socket.error as msg:
                    print("Error: Could not reveice result!")
                    print("Description:" + str(msg))
                    sys.exit(0)
        else:
            # Bind to listening port
            try:
                host=''  # Bind to all interfaces
                self.controlSocket.bind((host,4567))
            except socket.error as msg:
                print("Error: unable to bind on port %d" % 4567)
                print("Description: " + str(msg))
                sys.exit()

            # Listen
            try:
                backlog=10  # Number of incoming connections that can wait
                            # to be accept()'ed before being turned away
                self.controlSocket.listen(backlog)
                print("Lis")
            except socket.error as msg:
                print("Error: unable to listen()")
                print("Description: " + str(msg))
                sys.exit()    
            # Accept an incoming request
            while True:
                try:
                    (self.client_s, self.client_addr) = self.controlSocket.accept()
                    # If successful, we now have TWO sockets
                    #  (1) The original listening socket, still active
                    #  (2) The new socket connected to the client
                except socket.error as msg:
                    print("Error: unable to accept()")
                    print("Description: " + str(msg))
                    sys.exit()

                 # Receive data
                try:
                    buffer_size=20
                    dataPack = self.client_s.recv(buffer_size)
                except socket.error as msg:
                    print("Error: unable to recv()")
                    print("Description: " + str(msg))
                    sys.exit()
                self.Protocol, self.msg, self.Test = struct.unpack('3b', dataPack)
                print(dataPack)
                if self.msg == 1:
                    self.accept = True
                    while not self.replay:
                        time.sleep(1)
                    sendPack = struct.pack('!2b1h',1,2,1234)
                    try:
                        self.client_s.sendall(sendPack)
                    except socket.error as msg:
                        print("Error: unable to send reply")
                        print("Description: " + str(msg))
                        sys.exit()
                else:
                    if self.msg == b'Finished':
                        self.finished = True;
                        while not self.closedDataSocket:
                            time.sleep(1)
                        self.sendPack = self.generateResult()
                        try:
                            client_s.sendall(sendPack)
                        except socket.error as msg:
                            print("Error: unable to send reply")
                            print("Description: " + str(msg))
                            sys.exit()
