__author__ = 'ZYP'

import string
import threading
import sys
import socket
import struct
import time


class __client__(threading.Thread):

    def __init__(self, test, time, target):
        self.timer = time.time()
        self.Test = test.encode
        self.Time = time
        self.Target = target
        self.RRMode = self.Test.split('_')[1] == 'RR'
        self.TCPMode = self.Test.split('_')[0] == 'TCP'
        if self.RRMode:
            self.controlData = struct.pack('!5s1I5s',self.Test,self.Time,b'Start')
        else:
            self.controlData = struct.pack('!10s1I5s',self.Test,self.Time,b'Start')

    def generateData(self):

        if self.RRMode == 'RR':
            self.testData = struct.pack('!1s',b'')
        else:
            if self.TCPMode:
                self.testData = struct.pack('!65535s',b'')
            else:
                self.testData = struct.pack('!1472s',b'')


    def sendData(self):
        timer = time.time()
        received = True
        while time.time() >= timer+45 & received:
            if self.RRMode:
                if self.TCPMode:
                    self.dataSocket.sendall(self.testData)
                else:
                    self.dataSocket.sendto(self.testData,self.Target)
                try:
                    self.dataSocket.recv(1)
                except socket.error as msg:
                    received = False
    def run(self):
        try:
            self.controlSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        except socket.error as msg:
            print("Error: could not create control socket")
            print("Description:" + str(msg))
            sys.exit()
        try:
            self.controlSocket.connect((self.Target, 7654))
        except socket.error as msg:
            print("Error: could not open connecting")
            print("Description:" + str(msg))
            sys.exit()
        try:
            self.controlSocket.sendall(self.controlData)
        except socket.error as msg:
            print("Error: could not send control data")
            print("Description:" + str(msg))
            sys.exit()

        self.generateData()
        if self.Test == 'TCP_STREAM' or 'TCP_RR':
            try:
                self.dataSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            except socket.error as msg:
                print("Error: could not create Data socket")
                print("Description:" + str(msg))
                sys.exit()
        else:
            if self.Test == 'UDP_STREAM' or 'UDP_RR':
                try:
                    self.dataSocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                except socket.error as msg:
                    print("Error: could not create Data socket")
                    print("Description:" + str(msg))
                    sys.exit()