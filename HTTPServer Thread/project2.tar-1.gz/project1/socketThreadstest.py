﻿#!/usr/bin/env python3
import sys
import socket
import os
import string
import sys
import time
import threading
import mimetypes
import datetime
import socket

class socketThreadstest(threading.Thread):
    def __init__(self,threadname,Port,Verbose,Path,socketObj,client_s,client_addr): 
        self.port = Port
        self.verbose = Verbose
        self.path = Path
        self.socketObj = socketObj
        self.keepconnect = False
        self.fileRemain = 0;
        self.client_s = client_s
        self.client_addr = client_addr
        self.filesize = 1
        
        threading.Thread.__init__(self,name=threadname)
    def recievedHeader(self):
        if self.verbose:
            print("Accepted incoming connection from client")
            print("Client IP, Port = %s" % str(self.client_addr))
   # Receive data

        try:
            buffer_size = 512
            self.raw_bytes = self.client_s.recv(buffer_size)
        except socket.error as msg:
            print("Error: unable to recv()")
            print("Description: " + str(msg))
            sys.exit()
        self.string_unicode = self.raw_bytes.decode('ascii')
        if self.verbose:
            print("Received %d bytes from client" % len(self.raw_bytes))
            print("Message contents: \n")
            print("%s" % self.string_unicode)
        

    def decodeRequest(self):
        # Decoding HTTP header 
        #dirGet = string_unicode.rsplit()
        #print(dirGet)
        dirGet = "/"
        if (len(self.string_unicode) == 0):
            self.client_s.close()
            self.keepconnect = False
        else:
            for i in range(len(self.string_unicode)):
                if (self.string_unicode.rsplit()[i] == "keep-alive"):
                    self.keepconnect = True
                    break;
                else:
                    self.keepconnect = False
            if (self.fileRemain == self.filesize - 1):
                try:
                    dirGet = self.string_unicode.rsplit()[1]
                except Exception as e:
                    dirGet = "/"
                if dirGet == "/":
                    self.path += "/index.html"
                    self.openFile(self.path)
                else:
                    self.path += dirGet
                    self.openFile(self.path)
            if self.verbose:
                print("serving file: " + dirGet)
            
            sdata = self.HttpResponse(self.path)
                # send data
            try:  
                if self.verbose:
                    print("Send data")
                self.client_s.sendall(sdata)
            except socket.error as msg:  
                print ("Error sending data")
                print("Description: " + str(msg))
                sys.exit()
            try:
                if not self.keepconnect:
                    self.client_s.close()
                    #print("Sockets closed")
                
                #self.socketObj.close()
            except socket.error as msg:
                print("Error: unable to close() socket")
                print("Description: " + str(msg))
                sys.exit()
       
    def run(self):
        while True:
            if ((self.filesize > 512) & (self.fileRemain != self.filesize - 1)): 
                self.decodeRequest()
            else:
                self.recievedHeader()
                self.decodeRequest()
            if not self.keepconnect:
                break;
        
    def openFile(self,whtml):
        try:
            self.file_handler = open(whtml,'rb')
            self.response_content = self.file_handler.readlines()
            self.file_handler.close()
            return self.response_content
        except Exception as e:
            self.response_content = "Not Found"
            print(e);
            return self.response_content

    def HttpResponse(self,whtml):
            #HTTP Header
        server_response = b''
        httpheaderOK = b'HTTP/1.1 200 OK \r\n'
        httpHeaderDate = b'Date:'
        httpHearderServer = b'Server: Python version 1.0 \r\n'
        httpHearderContextType = b'Context-Type: '
        httpHearderContentLength = b'Content-Length: '
        httpHearderLastmodified = b'Last-Modified: '
        httpHeaderExpires = b'Expires: '
        if self.keepconnect:
            httpHeaderConnection = b'Keep-Alive: timeout=5, max=98 \r\nConnection: Keep-alive \r\n'
        else:
             httpHeaderConnection = b'Keep-Alive: timeout=5, max=98 \r\nConnection: Closed \r\n'
        httphearderNotFound = b'HTTP/1.1 404 Not Found \r\n\r\n'
        if self.response_content == "Not Found": 
            server_response = httphearderNotFound
            self.keepconnect = False
            return server_response
        else:
            try:
                self.filesize = os.path.getsize(whtml)
                if (self.filesize > 512 & self.fileRemain != 0):
                    temp = self.fileRemain
                    for self.fileRemain in range (len(self.response_content)):
                        server_response +=  self.response_content[self.fileRemain]
                        if self.fileRemain == temp + 512:
                            break
                        if self.fileRemain == len(self.response_content) - 1:
                            self.keepconnect = False
                else:
                    server_response += httpheaderOK
                    server_response += httpHeaderDate
                    server_response += (time.strftime("%a, %d %b %Y %H:%M:%S",time.localtime(time.time())) + " \r\n").encode()
                    server_response += httpHearderServer
                    server_response += httpHearderContextType
                    if mimetypes.guess_type(whtml)[0] == None:
                        server_response += ("Unknow Type" + " \r\n").encode()
                    else:
                        server_response += (mimetypes.guess_type(whtml)[0] + " \r\n").encode()
                    server_response += httpHearderContentLength
                    server_response += (str(os.path.getsize(whtml)) + " \r\n").encode()
                    server_response += httpHearderLastmodified
                    timestemp = os.path.getmtime(whtml)
                    date = datetime.datetime.fromtimestamp(timestemp)
                    server_response += (date.strftime("%a, %d %b %Y %H:%M:%S", )+" \r\n").encode()
                    timestemp = time.time() + 43200
                    date = datetime.datetime.fromtimestamp(timestemp)
                    server_response += httpHeaderExpires
                    server_response += (date.strftime("%a, %d %b %Y %H:%M:%S", )+" \r\n").encode()
                    server_response += httpHeaderConnection
                    server_response += b'\r\n'
                    temp = self.fileRemain
                    for self.fileRemain in range (len(self.response_content)):
                        server_response +=  self.response_content[self.fileRemain]
                        if self.fileRemain == temp + 512:

                            break
                        if self.fileRemain == len(self.response_content) - 1:
                            self.keepconnect = False
                return server_response
            except Exception as e:
                server_response = httphearderNotFound
                print(e)
                return server_response